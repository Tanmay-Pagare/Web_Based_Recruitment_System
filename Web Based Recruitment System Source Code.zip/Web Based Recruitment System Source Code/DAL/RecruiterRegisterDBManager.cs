﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using System.Data;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace DAL
{
    public class RecruiterRegisterDBManager
    {

        public static readonly string connString = string.Empty;

        static RecruiterRegisterDBManager()
        {
            connString = ConfigurationManager.ConnectionStrings["dbString"].ConnectionString;
        }

        public static List<RecruiterRegister> GetAllRecruiterRegister()
        {
            List<RecruiterRegister> allRecruiterRegister = new List<RecruiterRegister>();

            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            String query = "Select * from recruiter_register";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();

            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    RecruiterRegister theRecruiterRegister = new RecruiterRegister();
                    theRecruiterRegister.recruiterId = int.Parse(row["recruiterId"].ToString());
                    theRecruiterRegister.firstName = row["firstName"].ToString();
                    theRecruiterRegister.lastName = row["lastName"].ToString();
                    theRecruiterRegister.email = row["email"].ToString();
                    theRecruiterRegister.password = row["password"].ToString();
                    theRecruiterRegister.companyName = row["companyName"].ToString();
                    theRecruiterRegister.companyAddress = row["companyAddress"].ToString();
                    allRecruiterRegister.Add(theRecruiterRegister);

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return allRecruiterRegister;
        }


        public static RecruiterRegister GetRecruiterRegisterById(int id)
        {
            RecruiterRegister theRecruiterRegister = new RecruiterRegister();
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from recruiter_register where recruiterId=" + id;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    theRecruiterRegister.recruiterId = int.Parse(row["recruiterId"].ToString());
                    theRecruiterRegister.firstName = row["firstName"].ToString();
                    theRecruiterRegister.lastName = row["lastName"].ToString();
                    theRecruiterRegister.email = row["email"].ToString();
                    theRecruiterRegister.password = row["password"].ToString();
                    theRecruiterRegister.companyName = row["companyName"].ToString();
                    theRecruiterRegister.companyAddress = row["companyAddress"].ToString();
                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return theRecruiterRegister;
        }


        public static bool Insert(RecruiterRegister newRecruiterRegister)
        {

            bool status = false;
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from recruiter_register";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                MySqlCommandBuilder cmdbuilder = new MySqlCommandBuilder(da);
                da.Fill(ds);
                DataRow row = ds.Tables[0].NewRow();
                row["firstName"] = newRecruiterRegister.firstName;
                row["lastName"] = newRecruiterRegister.lastName;
                row["email"] = newRecruiterRegister.email;
                row["password"] = newRecruiterRegister.password;
                row["companyName"] = newRecruiterRegister.companyName;
                row["companyAddress"] = newRecruiterRegister.companyAddress;
                ds.Tables[0].Rows.Add(row);
                da.Update(ds);
                status = true;



            }
            catch (MySqlException e)
            {

            }

            return status;
        }

        public static bool update(RecruiterRegister theRecruiterRegister)
        {
            bool status = false;
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = "select * from recruiter_register";
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                MySqlCommandBuilder cmdbuilder = new MySqlCommandBuilder(da);
                da.Fill(ds);
                DataColumn[] keyColumns = new DataColumn[1];
                keyColumns[0] = ds.Tables[0].Columns["recruiterId"];
                ds.Tables[0].PrimaryKey = keyColumns;
                DataRow datarow = ds.Tables[0].Rows.Find(theRecruiterRegister.recruiterId);
                datarow["firstName"] = theRecruiterRegister.firstName;
                datarow["lastName"] = theRecruiterRegister.lastName;
                datarow["email"] = theRecruiterRegister.email;
                datarow["password"] = theRecruiterRegister.password;
                datarow["companyName"] = theRecruiterRegister.companyName;
                datarow["companyAddress"] = theRecruiterRegister.companyAddress;
                da.Update(ds);
                status = true;


            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }

            return status;
        }

        public static bool Delete(int id)
        {
            bool status = false;
            try
            {
                using (MySqlConnection con = new MySqlConnection(connString))
                {
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }
                    string query = "Delete from recruiter_register where recruiterId=@id";
                    MySqlCommand cmd = new MySqlCommand(query, con);
                    cmd.Parameters.Add(new MySqlParameter("@id", id));
                    cmd.ExecuteNonQuery();
                    con.Close();
                    status = true;

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }

            return status;
        }

        public static RecruiterRegister GetRecruiterByEmailAndPassword(String email,String pass)
        {
            RecruiterRegister theRecruiterRegister = new RecruiterRegister();
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from recruiter_register where email='" + email + "' AND password='" + pass + "'";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    theRecruiterRegister.recruiterId = int.Parse(row["recruiterId"].ToString());
                    theRecruiterRegister.firstName = row["firstName"].ToString();
                    theRecruiterRegister.lastName = row["lastName"].ToString();
                    theRecruiterRegister.email = row["email"].ToString();
                    theRecruiterRegister.password = row["password"].ToString();
                    theRecruiterRegister.companyName = row["companyName"].ToString();
                    theRecruiterRegister.companyAddress = row["companyAddress"].ToString();
                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return theRecruiterRegister;

        }

    }
}
