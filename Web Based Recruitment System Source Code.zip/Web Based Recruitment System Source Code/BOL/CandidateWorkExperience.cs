﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOL
{
     public class CandidateWorkExperience
    {

        public int experienceId { get; set; }

        public string jobTitle { get; set; }

        public string companyName { get; set; }

        public string workCity { get; set; }

        public string designation { get; set; }

        public int duration { get; set; }

        public int candidateId { get; set; }

    }
}
