﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BLL;
using BOL;

namespace webbaserecruitment.Controllers
{
    public class RecruiterRegisterController : Controller
    {

        public ActionResult recruitmentHome()
        {
            if (Session["regLogin"] != null)
            {

                RecruiterRegister rec = new RecruiterRegister();
                rec = (RecruiterRegister)Session["regLogin"];
                return View(rec);
            }
            else
            {
                return null;
            }


        }


        // GET: RecruiterRegister
        public ActionResult Index()
        {
            List<RecruiterRegister> allRecruiterRegister = RecruiterRegisterBusinessManager.GetAllRecruiterRegister();

            this.ViewData["recruiterRegister"] = allRecruiterRegister;
            return View();
        }

        public ActionResult Details(int id)
        {
            RecruiterRegister theRecruiterRegister = RecruiterRegisterBusinessManager.GetById(id);

            return View(theRecruiterRegister);
        }

        public ActionResult Insert()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Insert(string firstName, string lastName, string email, string password, string companyName, string companyAddress)
        {
            RecruiterRegister theRecruiterRegister = new RecruiterRegister { firstName = firstName, lastName = lastName, email = email, password = password, companyName = companyName, companyAddress = companyAddress };
            bool status = RecruiterRegisterBusinessManager.insert(theRecruiterRegister);
            if (status)
            {
                return this.RedirectToAction("index", "home");
            }

            return View();
        }

        public ActionResult Update(int id)
        {
            RecruiterRegister theRecruiterRegister = RecruiterRegisterBusinessManager.GetById(id);
            return View(theRecruiterRegister);
        }
        [HttpPost]
        public ActionResult Update(int id, string firstName, string lastName, string email, string password, string companyName, string companyAddress)
        {
            RecruiterRegister theRecruiterRegister = new RecruiterRegister
            {
                recruiterId = id,
                firstName = firstName,
                lastName = lastName,
                email = email,
                password = password,
                companyName= companyName,
                companyAddress= companyAddress

            };
            bool status = RecruiterRegisterBusinessManager.Update(theRecruiterRegister);
            if (status)
            {
                return this.RedirectToAction("recruitmentHome", "RecruiterRegister");

            }
            return View();
        }


        public ActionResult Delete(int id)
        {
            bool status = RecruiterRegisterBusinessManager.delete(id);
            if (status == true)
            {
                return this.RedirectToAction("index", "RecruiterRegister");


            }
            return View();
        }


      

       

    }
}