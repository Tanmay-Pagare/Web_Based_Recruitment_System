﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using DAL;

namespace BLL
{
    public class RecruiterJobPostBusinessManager
    {
        public static List<RecruiterJobPost> GetAllRecruiterJobPost()
        {

            List<RecruiterJobPost> allRecruiterJobPost = new List<RecruiterJobPost>();
            allRecruiterJobPost = RecruiterJobPostDBManager.GetAllRecruiterJobPost();
            return allRecruiterJobPost;
        }

        public static List<RecruiterJobPost> GetByRecruiterId(int id)
        {
            List<RecruiterJobPost> allRecruiterJobPost = new List<RecruiterJobPost>();
            allRecruiterJobPost = RecruiterJobPostDBManager.GetRecruiterJobPostByRecruiterId(id);
            return allRecruiterJobPost;

        }


        public static bool insert(RecruiterJobPost newRecruiterJobPost)
        {
            bool status = RecruiterJobPostDBManager.Insert(newRecruiterJobPost);
            return status;
        }

        public static bool Update(RecruiterJobPost theRecruiterJobPost)
        {
            return RecruiterJobPostDBManager.update(theRecruiterJobPost);
        }

        public static bool delete(int id)
        {
            return RecruiterJobPostDBManager.Delete(id);
        }


        public static RecruiterJobPost GetById(int id)
        {
            RecruiterJobPost theRecruiterJobPost = new RecruiterJobPost();
            theRecruiterJobPost = RecruiterJobPostDBManager.GetRecruiterJobPostById(id);
            return theRecruiterJobPost;

        }


        public static List<RecruiterJobPost> GetAllRecruiterJobPostByTitleAndCity(String title,String city)
        {

            List<RecruiterJobPost> allJobPostByTitleAndCity = new List<RecruiterJobPost>();
            allJobPostByTitleAndCity = RecruiterJobPostDBManager.GetJobPostByTitleAndCity(title, city);
            return allJobPostByTitleAndCity;
        }

        public static List<CandidateRegister> GetAppliedCandidate(int JobId)
        {
            List<CandidateRegister> allAppliedCandidates = new List<CandidateRegister>();
            allAppliedCandidates = RecruiterJobPostDBManager.GetAllAppliedCandidate(JobId);
            return allAppliedCandidates;

        }


    }
}
