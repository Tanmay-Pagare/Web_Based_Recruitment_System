﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using System.Data;
using MySql.Data.MySqlClient;
using System.Configuration;



namespace DAL
{
    public class CandidateWorkExperienceDBManager
    {

        public static readonly string connString = string.Empty;

        static CandidateWorkExperienceDBManager()
        {
            connString = ConfigurationManager.ConnectionStrings["dbString"].ConnectionString;
        }

        public static List<CandidateWorkExperience> GetAllCandidateWorkExperience()
        {
            List<CandidateWorkExperience> allCandidateWorkExperience = new List<CandidateWorkExperience>();

            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            String query = "Select * from candidate_experience";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();

            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    CandidateWorkExperience theCandidateWorkExperience = new CandidateWorkExperience();
                    theCandidateWorkExperience.experienceId = int.Parse(row["experienceId"].ToString());
                    theCandidateWorkExperience.jobTitle = row["jobTitle"].ToString();
                    theCandidateWorkExperience.companyName = row["companyName"].ToString();
                    theCandidateWorkExperience.workCity = row["workCity"].ToString();
                    theCandidateWorkExperience.designation = row["designation"].ToString();
                    theCandidateWorkExperience.duration = int.Parse(row["duration"].ToString());
                    allCandidateWorkExperience.Add(theCandidateWorkExperience);

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return allCandidateWorkExperience;
        }


        public static List<CandidateWorkExperience> GetCandidateWorkExperienceByCandidateId(int id)
        {
            List<CandidateWorkExperience> allCandidateWorkExperience = new List<CandidateWorkExperience>();
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from candidate_experience where candidateId=" + id;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    CandidateWorkExperience theCandidateWorkExperience = new CandidateWorkExperience();
                    theCandidateWorkExperience.experienceId = int.Parse(row["experienceId"].ToString());
                    theCandidateWorkExperience.jobTitle = row["jobTitle"].ToString();
                    theCandidateWorkExperience.companyName = row["companyName"].ToString();
                    theCandidateWorkExperience.workCity = row["workCity"].ToString();
                    theCandidateWorkExperience.designation = row["designation"].ToString();
                    theCandidateWorkExperience.duration = int.Parse(row["duration"].ToString());
                    theCandidateWorkExperience.candidateId = int.Parse(row["candidateId"].ToString());
                    allCandidateWorkExperience.Add(theCandidateWorkExperience);

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }



            return allCandidateWorkExperience;
        }



        public static CandidateWorkExperience GetCandidateWorkExperienceById(int id)
        {
            CandidateWorkExperience theCandidateWorkExperience = new CandidateWorkExperience();
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from candidate_experience where experienceId=" + id;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    theCandidateWorkExperience.experienceId = int.Parse(row["experienceId"].ToString());
                    theCandidateWorkExperience.jobTitle = row["jobTitle"].ToString();
                    theCandidateWorkExperience.companyName = row["companyName"].ToString();
                    theCandidateWorkExperience.workCity = row["workCity"].ToString();
                    theCandidateWorkExperience.designation = row["designation"].ToString();
                    theCandidateWorkExperience.duration = int.Parse(row["duration"].ToString());

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return theCandidateWorkExperience;
        }



        public static bool Insert(CandidateWorkExperience newCandidateWorkExperience)
        {

            bool status = false;
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from candidate_experience";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                MySqlCommandBuilder cmdbuilder = new MySqlCommandBuilder(da);
                da.Fill(ds);
                DataRow row = ds.Tables[0].NewRow();
                row["jobTitle"] = newCandidateWorkExperience.jobTitle;
                row["companyName"] = newCandidateWorkExperience.companyName;
                row["workCity"] = newCandidateWorkExperience.workCity;
                row["designation"] = newCandidateWorkExperience.designation;
                row["duration"] = newCandidateWorkExperience.duration;
                row["candidateId"] = newCandidateWorkExperience.candidateId;
                ds.Tables[0].Rows.Add(row);
                da.Update(ds);
                status = true;



            }
            catch (MySqlException e)
            {

            }

            return status;
        }

        public static bool update(CandidateWorkExperience theCandidateWorkExperience)
        {
            bool status = false;
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = "select * from candidate_experience";
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                MySqlCommandBuilder cmdbuilder = new MySqlCommandBuilder(da);
                da.Fill(ds);
                DataColumn[] keyColumns = new DataColumn[1];
                keyColumns[0] = ds.Tables[0].Columns["experienceId"];
                ds.Tables[0].PrimaryKey = keyColumns;
                DataRow datarow = ds.Tables[0].Rows.Find(theCandidateWorkExperience.experienceId);
                datarow["jobTitle"] = theCandidateWorkExperience.jobTitle;
                datarow["companyName"] = theCandidateWorkExperience.companyName;
                datarow["workCity"] = theCandidateWorkExperience.workCity;
                datarow["designation"] = theCandidateWorkExperience.designation;
                datarow["duration"] = theCandidateWorkExperience.duration;
                da.Update(ds);
                status = true;


            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }

            return status;
        }

        public static bool Delete(int id)
        {
            bool status = false;
            try
            {
                using (MySqlConnection con = new MySqlConnection(connString))
                {
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }
                    string query = "Delete from candidate_experience where experienceId=@id";
                    MySqlCommand cmd = new MySqlCommand(query, con);
                    cmd.Parameters.Add(new MySqlParameter("@id", id));
                    cmd.ExecuteNonQuery();
                    con.Close();
                    status = true;

                  

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }

            return status;
        }





        public static bool deleteData(int pid)
        {
            bool status = false;
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "Select * from candidate_experience";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;

            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                MySqlCommandBuilder cmdbuilder = new MySqlCommandBuilder(da);
                da.Fill(ds);
                DataColumn[] keysColumns = new DataColumn[1];
                keysColumns[0] = ds.Tables[0].Columns["experienceId"];
                ds.Tables[0].PrimaryKey = keysColumns;
                DataRow dataRow = ds.Tables[0].Rows.Find(pid);
                dataRow.Delete();
                da.Update(ds);
                status = true;
            }
            catch (MySql.Data.MySqlClient.MySqlException e)
            {
                string msg = e.Message;
            }

            return status;
        }




    }
}
