﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BLL;
using BOL;

namespace webbaserecruitment.Controllers
{
    public class RecruiterJobPostController : Controller
    {


        public ActionResult SearchByTitleAndCity()
        {

           /* if (Session["canLogin"] != null)
            {*/
                // location = (LocationByAddressReply)TempData["myObject"];
                List<RecruiterJobPost> JobByTitleAndCity = new List<RecruiterJobPost>();
                JobByTitleAndCity = (List<RecruiterJobPost>)Session["JobByTitleAndCity"];

                this.ViewData["JobPostByTitleAndCity"] = JobByTitleAndCity;

                CandidateRegister can = new CandidateRegister();
                can = (CandidateRegister)Session["canLogin"];

                this.ViewData["can"] = can;
                if(JobByTitleAndCity.Any())
                { 
                    return View();
                }
                else
                {
                    return this.RedirectToAction("nojobfound", "RecruiterJobPost");

                }
            /*}*/
        }

        public ActionResult nojobfound()
        {
            return View();
        }

        [HttpPost]
        public ActionResult SearchByTitleAndCity(bool status,int jobId,int candidateId)
        {
            AppliedJobPost jobApplied = new AppliedJobPost { status = status, jobId = jobId, candidateId = candidateId };
            bool flag = AppliedJobPostBusinessManager.insert(jobApplied);
            if(flag)
            {
                return this.RedirectToAction("AppliedSuccessful", "RecruiterJobPost");
            }
            return View();
        }

        public ActionResult AppliedSuccessful()
        {
            return View();
        }


            // GET: RecruiterJobPost
            public ActionResult Index()
        {
            List<RecruiterJobPost> allRecruiterJobPost = RecruiterJobPostBusinessManager.GetAllRecruiterJobPost();
            this.ViewData["recruiterJobPost"] = allRecruiterJobPost;
            return View();
        }

        public ActionResult appcan(int id)
        {
            return View();
        }

        public ActionResult appliedCandidateInfo(int id)
        {
             List<CandidateRegister> allAppliedCandidates = RecruiterJobPostBusinessManager.GetAppliedCandidate(id);
             this.ViewData["appliedCandidates"] = allAppliedCandidates;
             if(allAppliedCandidates.Any())
             {
                return View();
             }
             else
             {
                return this.RedirectToAction("nocanapplied", "RecruiterJobPost");

             }

        }

        public ActionResult nocanapplied()
        {
            return View();
        }

            public ActionResult Details(int id)
        {
            List<RecruiterJobPost> allRecruiterJobPost = RecruiterJobPostBusinessManager.GetByRecruiterId(id);
            this.ViewData["jobpost"] = allRecruiterJobPost;
            if(allRecruiterJobPost.Any())
            {
                return View();
            }
            else
            {
                return this.RedirectToAction("nojobpost", "RecruiterJobPost");

            }

        }

        public ActionResult nojobpost()
        {
            return View();
        }

            public ActionResult Insert(int id)
        {
            ViewBag.LinkableId = id;
            return View();
        }

        [HttpPost]
        public ActionResult Insert(string jobTitle, string location, string remoteWork, string numberVacancy,
                string companyDescription, string industryType, string companySize, string employeementType,
                int minSalary, int maxSalary, string skillsRequired, int experienceRequired, string designation,
                 DateTime postdate, int recruiterId )
        {
            RecruiterJobPost theRecruiterJobPost = new RecruiterJobPost
            {
                jobTitle = jobTitle,
                location = location,
                remoteWork = remoteWork,
                numberVacancy = numberVacancy,
                companyDescription = companyDescription,
                industryType = industryType,
                companySize = companySize,
                employeementType = employeementType,
                minSalary = minSalary,
                maxSalary = maxSalary,
                skillsRequired = skillsRequired,
                experienceRequired = experienceRequired,
                designation = designation,
                postdate = DateTime.Now,
                recruiterId= recruiterId

            };
            bool status = RecruiterJobPostBusinessManager.insert(theRecruiterJobPost);
            if (status)
            {
                return this.RedirectToAction("recruitmentHome", "RecruiterRegister");
            }

            return View();
        }

        public ActionResult Update(int id)
        {
            RecruiterJobPost theRecruiterJobPost = RecruiterJobPostBusinessManager.GetById(id);
            return View(theRecruiterJobPost);
        }

        [HttpPost]
        public ActionResult Update(int id, string jobTitle, string location, string remoteWork, string numberVacancy,
                string companyDescription, string industryType, string companySize, string employeementType,
                int minSalary, int maxSalary, string skillsRequired, int experienceRequired, string designation,
                 DateTime postdate)
        {
            RecruiterJobPost theRecruiterJobPost = new RecruiterJobPost
            {
                jobId = id,
                jobTitle = jobTitle,
                location = location,
                remoteWork = remoteWork,
                numberVacancy = numberVacancy,
                companyDescription = companyDescription,
                industryType = industryType,
                companySize = companySize,
                employeementType = employeementType,
                minSalary = minSalary,
                maxSalary = maxSalary,
                skillsRequired = skillsRequired,
                experienceRequired = experienceRequired,
                designation = designation,
                postdate = postdate,


            };
            bool status = RecruiterJobPostBusinessManager.Update(theRecruiterJobPost);
            if (status)
            {
                return this.RedirectToAction("recruitmentHome", "RecruiterRegister");

            }
            return View();
        }


        public ActionResult Delete(int id)
        {
            bool status = RecruiterJobPostBusinessManager.delete(id);
            if (status == true)
            {
                return this.RedirectToAction("recruitmentHome", "RecruiterRegister");


            }
            return View();
        }


    }
}