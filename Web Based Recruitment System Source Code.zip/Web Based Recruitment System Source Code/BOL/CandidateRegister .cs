﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BOL
{
    public class CandidateRegister
    {

        public int candidateId { get; set; }

        public string firstName { get; set; }

        public string lastName { get; set; }

        public string email { get; set; }

        public string password { get; set; }

        public string gender { get; set; }

        public DateTime dob { get; set; }

        public string canAddr { get; set; }

        public string phoneNum { get; set; }

        public string state { get; set; }

        public string city { get; set; }

        public string altEmail { get; set; }

        public int pincode { get; set; }

        public string schoolName { get; set; }

        public string tenthBoardname { get; set; }

        public double schoolPercentage { get; set; }

        public int schoolPassingyear { get; set; }

        public string hscCollegeName { get; set; }

        public string hscBoardName { get; set; }

        public double hscPercentage { get; set; }

        public int hscPassingyear { get; set; }

        public string collegeName { get; set; }

        public string universityName { get; set; }

        public string stream { get; set; }

        public double graduationPercentage { get; set; }

        public int graduationPassingYear { get; set; }

        public string projectTitle { get; set; }

        public string projectDetails { get; set; }

        public string certification { get; set; }


        public CandidateRegister ()
        {

        }


        public CandidateRegister(String email,String password)
        {
            this.email = email;
            this.password = password;

        }


    }
}
