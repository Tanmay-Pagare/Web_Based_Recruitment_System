﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BOL;
using System.Data;
using MySql.Data.MySqlClient;
using System.Configuration;

namespace DAL
{
    public class RecruiterJobPostDBManager
    {
        public static readonly string connString = string.Empty;

        static RecruiterJobPostDBManager()
        {
            connString = ConfigurationManager.ConnectionStrings["dbString"].ConnectionString;
        }


        public static List<CandidateRegister> GetAllAppliedCandidate(int jobId)
        {
            List<CandidateRegister> allCandidateRegister = new List<CandidateRegister>();

            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            /*String query = "Select * from candidate_register";*/
            String query = "SELECT * FROM candidate_register WHERE candidateId IN( SELECT candidateId FROM applied_job WHERE jobId =" + jobId + "); ";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();

            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    CandidateRegister theCandidateRegister = new CandidateRegister();
                    theCandidateRegister.candidateId = int.Parse(row["candidateId"].ToString());
                    theCandidateRegister.firstName = row["firstName"].ToString();
                    theCandidateRegister.lastName = row["lastName"].ToString();
                    theCandidateRegister.email = row["email"].ToString();
                    theCandidateRegister.password = row["password"].ToString();
                    theCandidateRegister.gender = row["gender"].ToString();
                    theCandidateRegister.dob = DateTime.Parse(row["dob"].ToString());
                    theCandidateRegister.canAddr = row["canAddr"].ToString();
                    theCandidateRegister.phoneNum = row["phoneNum"].ToString();
                    theCandidateRegister.state = row["state"].ToString();
                    theCandidateRegister.city = row["city"].ToString();
                    theCandidateRegister.altEmail = row["altEmail"].ToString();
                    theCandidateRegister.pincode = int.Parse(row["pincode"].ToString());
                    theCandidateRegister.schoolName = row["schoolName"].ToString();
                    theCandidateRegister.tenthBoardname = row["tenthBoardname"].ToString();
                    theCandidateRegister.schoolPercentage = double.Parse(row["schoolPercentage"].ToString());
                    theCandidateRegister.schoolPassingyear = int.Parse(row["schoolPassingyear"].ToString());
                    theCandidateRegister.hscCollegeName = row["hscCollegeName"].ToString();
                    theCandidateRegister.hscBoardName = row["hscBoardName"].ToString();
                    theCandidateRegister.hscPercentage = double.Parse(row["hscPercentage"].ToString());
                    theCandidateRegister.hscPassingyear = int.Parse(row["hscPassingyear"].ToString());
                    theCandidateRegister.collegeName = row["collegeName"].ToString();
                    theCandidateRegister.universityName = row["universityName"].ToString();
                    theCandidateRegister.stream = row["stream"].ToString();
                    theCandidateRegister.graduationPercentage = double.Parse(row["graduationPercentage"].ToString());
                    theCandidateRegister.graduationPassingYear = int.Parse(row["graduationPassingYear"].ToString());
                    theCandidateRegister.projectTitle = row["projectTitle"].ToString();
                    theCandidateRegister.projectDetails = row["projectDetails"].ToString();
                    theCandidateRegister.certification = row["certification"].ToString();

                    allCandidateRegister.Add(theCandidateRegister);

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return allCandidateRegister;
        

        }


        public static List<RecruiterJobPost> GetAllRecruiterJobPost()
        {
            List<RecruiterJobPost> allRecruiterJobPost = new List<RecruiterJobPost>();

            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            String query = "Select * from recruiter_jobpost";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();

            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    RecruiterJobPost theRecruiterJobPost = new RecruiterJobPost();
                    theRecruiterJobPost.jobId = int.Parse(row["jobId"].ToString());
                    theRecruiterJobPost.jobTitle = row["jobTitle"].ToString();
                    theRecruiterJobPost.location = row["location"].ToString();
                    theRecruiterJobPost.remoteWork = row["remoteWork"].ToString();
                    theRecruiterJobPost.numberVacancy = row["numberVacancy"].ToString();
                    theRecruiterJobPost.companyDescription = row["companyDescription"].ToString();
                    theRecruiterJobPost.industryType = row["industryType"].ToString();
                    theRecruiterJobPost.companySize = row["companySize"].ToString();
                    theRecruiterJobPost.employeementType = row["employeementType"].ToString();
                    theRecruiterJobPost.minSalary = int.Parse(row["minSalary"].ToString());
                    theRecruiterJobPost.maxSalary = int.Parse(row["maxSalary"].ToString());
                    theRecruiterJobPost.skillsRequired = row["skillsRequired"].ToString();
                    theRecruiterJobPost.experienceRequired = int.Parse(row["experienceRequired"].ToString());
                    theRecruiterJobPost.designation = row["designation"].ToString();
                    theRecruiterJobPost.postdate = DateTime.Parse(row["postdate"].ToString());
                

                    allRecruiterJobPost.Add(theRecruiterJobPost);

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return allRecruiterJobPost;
        }


        public static RecruiterJobPost GetRecruiterJobPostById(int id)
        {
            RecruiterJobPost theRecruiterJobPost = new RecruiterJobPost();
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from recruiter_jobpost where jobId=" + id;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    theRecruiterJobPost.jobId = int.Parse(row["jobId"].ToString());
                    theRecruiterJobPost.jobTitle = row["jobTitle"].ToString();
                    theRecruiterJobPost.location = row["location"].ToString();
                    theRecruiterJobPost.remoteWork = row["remoteWork"].ToString();
                    theRecruiterJobPost.numberVacancy = row["numberVacancy"].ToString();
                    theRecruiterJobPost.companyDescription = row["companyDescription"].ToString();
                    theRecruiterJobPost.industryType = row["industryType"].ToString();
                    theRecruiterJobPost.companySize = row["companySize"].ToString();
                    theRecruiterJobPost.employeementType = row["employeementType"].ToString();
                    theRecruiterJobPost.minSalary = int.Parse(row["minSalary"].ToString());
                    theRecruiterJobPost.maxSalary = int.Parse(row["maxSalary"].ToString());
                    theRecruiterJobPost.skillsRequired = row["skillsRequired"].ToString();
                    theRecruiterJobPost.experienceRequired = int.Parse(row["experienceRequired"].ToString());
                    theRecruiterJobPost.designation = row["designation"].ToString();
                    theRecruiterJobPost.postdate = DateTime.Parse(row["postdate"].ToString());
                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return theRecruiterJobPost;
        }





        public static List<RecruiterJobPost> GetRecruiterJobPostByRecruiterId(int id)
        {
            List<RecruiterJobPost> allRecruiterJobPost = new List<RecruiterJobPost>();
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from recruiter_jobpost where recruiterId=" + id;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {

                    RecruiterJobPost theRecruiterJobPost = new RecruiterJobPost();
                    theRecruiterJobPost.jobId = int.Parse(row["jobId"].ToString());
                    theRecruiterJobPost.jobTitle = row["jobTitle"].ToString();
                    theRecruiterJobPost.location = row["location"].ToString();
                    theRecruiterJobPost.remoteWork = row["remoteWork"].ToString();
                    theRecruiterJobPost.numberVacancy = row["numberVacancy"].ToString();
                    theRecruiterJobPost.companyDescription = row["companyDescription"].ToString();
                    theRecruiterJobPost.industryType = row["industryType"].ToString();
                    theRecruiterJobPost.companySize = row["companySize"].ToString();
                    theRecruiterJobPost.employeementType = row["employeementType"].ToString();
                    theRecruiterJobPost.minSalary = int.Parse(row["minSalary"].ToString());
                    theRecruiterJobPost.maxSalary = int.Parse(row["maxSalary"].ToString());
                    theRecruiterJobPost.skillsRequired = row["skillsRequired"].ToString();
                    theRecruiterJobPost.experienceRequired = int.Parse(row["experienceRequired"].ToString());
                    theRecruiterJobPost.designation = row["designation"].ToString();
                    theRecruiterJobPost.postdate = DateTime.Parse(row["postdate"].ToString());
                    theRecruiterJobPost.recruiterId = int.Parse(row["recruiterId"].ToString());

                    allRecruiterJobPost.Add(theRecruiterJobPost);
                    /* theRecruiterJobPost.jobId = int.Parse(row["jobId"].ToString());
                     theRecruiterJobPost.jobTitle = row["jobTitle"].ToString();
                     theRecruiterJobPost.location = row["location"].ToString();
                     theRecruiterJobPost.remoteWork = row["remoteWork"].ToString();
                     theRecruiterJobPost.numberVacancy = row["numberVacancy"].ToString();
                     theRecruiterJobPost.companyDescription = row["companyDescription"].ToString();
                     theRecruiterJobPost.industryType = row["industryType"].ToString();
                     theRecruiterJobPost.companySize = row["companySize"].ToString();
                     theRecruiterJobPost.employeementType = row["employeementType"].ToString();
                     theRecruiterJobPost.minSalary = int.Parse(row["minSalary"].ToString());
                     theRecruiterJobPost.maxSalary = int.Parse(row["maxSalary"].ToString());
                     theRecruiterJobPost.skillsRequired = row["skillsRequired"].ToString();
                     theRecruiterJobPost.experienceRequired = int.Parse(row["experienceRequired"].ToString());
                     theRecruiterJobPost.designation = row["designation"].ToString();
                     theRecruiterJobPost.postdate = DateTime.Parse(row["postdate"].ToString());
                     theRecruiterJobPost.recruiterId = int.Parse(row["recruiterId"].ToString());*/
                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return allRecruiterJobPost;
        }


        public static bool Insert(RecruiterJobPost newRecruiterJobPost)
        {

            bool status = false;
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            string query = "select * from recruiter_jobpost";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                MySqlCommandBuilder cmdbuilder = new MySqlCommandBuilder(da);
                da.Fill(ds);
                DataRow row = ds.Tables[0].NewRow();
                row["jobTitle"] = newRecruiterJobPost.jobTitle;
                row["location"] = newRecruiterJobPost.location;
                row["remoteWork"] = newRecruiterJobPost.remoteWork;
                row["numberVacancy"] = newRecruiterJobPost.numberVacancy;
                row["companyDescription"] = newRecruiterJobPost.companyDescription;
                row["industryType"] = newRecruiterJobPost.industryType;
                row["companySize"] = newRecruiterJobPost.companySize;
                row["employeementType"] = newRecruiterJobPost.employeementType;
                row["minSalary"] = newRecruiterJobPost.minSalary;
                row["maxSalary"] = newRecruiterJobPost.maxSalary;
                row["skillsRequired"] = newRecruiterJobPost.skillsRequired;
                row["experienceRequired"] = newRecruiterJobPost.experienceRequired;
                row["designation"] = newRecruiterJobPost.designation;
                row["postdate"] = newRecruiterJobPost.postdate;
                row["recruiterId"] = newRecruiterJobPost.recruiterId;

                ds.Tables[0].Rows.Add(row);
                da.Update(ds);
                status = true;



            }
            catch (MySqlException e)
            {

            }

            return status;
        }

        public static bool update(RecruiterJobPost theRecruiterJobPost)
        {
            bool status = false;
            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = "select * from recruiter_jobpost";
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();
            try
            {
                MySqlCommandBuilder cmdbuilder = new MySqlCommandBuilder(da);
                da.Fill(ds);
                DataColumn[] keyColumns = new DataColumn[1];
                keyColumns[0] = ds.Tables[0].Columns["jobId"];
                ds.Tables[0].PrimaryKey = keyColumns;
                DataRow datarow = ds.Tables[0].Rows.Find(theRecruiterJobPost.jobId);
                datarow["jobTitle"] = theRecruiterJobPost.jobTitle;
                datarow["location"] = theRecruiterJobPost.location;
                datarow["remoteWork"] = theRecruiterJobPost.remoteWork;
                datarow["numberVacancy"] = theRecruiterJobPost.numberVacancy;
                datarow["companyDescription"] = theRecruiterJobPost.companyDescription;
                datarow["industryType"] = theRecruiterJobPost.industryType;
                datarow["companySize"] = theRecruiterJobPost.companySize;
                datarow["employeementType"] = theRecruiterJobPost.employeementType;
                datarow["minSalary"] = theRecruiterJobPost.minSalary;
                datarow["maxSalary"] = theRecruiterJobPost.maxSalary;
                datarow["skillsRequired"] = theRecruiterJobPost.skillsRequired;
                datarow["experienceRequired"] = theRecruiterJobPost.experienceRequired;
                datarow["designation"] = theRecruiterJobPost.designation;
                datarow["postdate"] = theRecruiterJobPost.postdate;
                da.Update(ds);
                status = true;


            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }

            return status;
        }

        public static bool Delete(int id)
        {
            bool status = false;
            try
            {
                using (MySqlConnection con = new MySqlConnection(connString))
                {
                    if (con.State == ConnectionState.Closed)
                    {
                        con.Open();
                    }
                    string query = "Delete from recruiter_jobpost where jobId=@id";
                    MySqlCommand cmd = new MySqlCommand(query, con);
                    cmd.Parameters.Add(new MySqlParameter("@id", id));
                    cmd.ExecuteNonQuery();
                    con.Close();
                    status = true;

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }

            return status;
        }




        public static List<RecruiterJobPost> GetJobPostByTitleAndCity(String title,String city)
        {
            List<RecruiterJobPost> allRecruiterJobPost = new List<RecruiterJobPost>();

            IDbConnection conn = new MySqlConnection();
            conn.ConnectionString = connString;
            String query = "Select * from recruiter_jobpost where jobTitle='" + title + "' AND location='" + city + "'";
            IDbCommand cmd = new MySqlCommand();
            cmd.CommandText = query;
            cmd.Connection = conn;
            MySqlDataAdapter da = new MySqlDataAdapter(cmd as MySqlCommand);
            DataSet ds = new DataSet();

            try
            {
                da.Fill(ds);
                DataRowCollection rows = ds.Tables[0].Rows;
                foreach (DataRow row in rows)
                {
                    RecruiterJobPost theRecruiterJobPost = new RecruiterJobPost();
                    theRecruiterJobPost.jobId = int.Parse(row["jobId"].ToString());
                    theRecruiterJobPost.jobTitle = row["jobTitle"].ToString();
                    theRecruiterJobPost.location = row["location"].ToString();
                    theRecruiterJobPost.remoteWork = row["remoteWork"].ToString();
                    theRecruiterJobPost.numberVacancy = row["numberVacancy"].ToString();
                    theRecruiterJobPost.companyDescription = row["companyDescription"].ToString();
                    theRecruiterJobPost.industryType = row["industryType"].ToString();
                    theRecruiterJobPost.companySize = row["companySize"].ToString();
                    theRecruiterJobPost.employeementType = row["employeementType"].ToString();
                    theRecruiterJobPost.minSalary = int.Parse(row["minSalary"].ToString());
                    theRecruiterJobPost.maxSalary = int.Parse(row["maxSalary"].ToString());
                    theRecruiterJobPost.skillsRequired = row["skillsRequired"].ToString();
                    theRecruiterJobPost.experienceRequired = int.Parse(row["experienceRequired"].ToString());
                    theRecruiterJobPost.designation = row["designation"].ToString();
                    theRecruiterJobPost.postdate = DateTime.Parse(row["postdate"].ToString());
                    theRecruiterJobPost.recruiterId=int.Parse(row["recruiterId"].ToString());

                    allRecruiterJobPost.Add(theRecruiterJobPost);

                }

            }
            catch (MySqlException e)
            {
                string msg = e.Message;
            }


            return allRecruiterJobPost;
        }



    }
}
