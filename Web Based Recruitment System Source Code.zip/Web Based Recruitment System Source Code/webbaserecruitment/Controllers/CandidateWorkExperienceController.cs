﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BLL;
using BOL;

namespace webbaserecruitment.Controllers
{
    public class CandidateWorkExperienceController : Controller
    {
        // GET: CandidateWorkExperience
        public ActionResult Index()
        {
            List<CandidateWorkExperience> allCandidateWorkExperience = CandidateWorkExperienceBusinessManager.GetAllCandidateWorkExperience();
            this.ViewData["candidateWorkExperience"] = allCandidateWorkExperience;
            return View();
        }


        public ActionResult appliedCandidateWorkDetails(int id)
        {
            List<CandidateWorkExperience> allCandidateWorkExperience = CandidateWorkExperienceBusinessManager.GetByCandidateId(id);
            this.ViewData["candidateWorkExperience"] = allCandidateWorkExperience;
            return View();

        }

        public ActionResult Details(int id)
        {
            List<CandidateWorkExperience> allCandidateWorkExperience = CandidateWorkExperienceBusinessManager.GetByCandidateId(id);
            this.ViewData["candidateWorkExperience"] = allCandidateWorkExperience;
            return View();
        }

        public ActionResult insert(int id)
        {
            ViewBag.LinkableId = id;
            // int canID = int.Parse(id);
            // this.ViewData["canId"] = id;
            return View();
        }

        [HttpPost]
        public ActionResult insert(string jobTitle, string companyName, string workCity, string designation, int duration,int candidateId)
        {
            CandidateWorkExperience theCandidateWorkExperience = new CandidateWorkExperience { jobTitle = jobTitle, companyName = companyName, workCity = workCity, designation = designation, duration = duration, candidateId= candidateId };
            bool status = CandidateWorkExperienceBusinessManager.insert(theCandidateWorkExperience);
            if (status)
            {
                return this.RedirectToAction("canhome", "CandidateRegister");
            }

            return View();
        }

        public ActionResult Update(int id)
        {
            CandidateWorkExperience theCandidateWorkExperience = CandidateWorkExperienceBusinessManager.GetById(id);
            return View(theCandidateWorkExperience);
        }
        [HttpPost]
        public ActionResult Update(int id, string jobTitle, string companyName, string workCity, string designation, int duration)
        {
            CandidateWorkExperience theCandidateWorkExperience = new CandidateWorkExperience
            {
                experienceId = id,
                jobTitle = jobTitle,
                companyName = companyName,
                workCity = workCity,
                designation = designation,
                duration = duration,

            };
            bool status = CandidateWorkExperienceBusinessManager.Update(theCandidateWorkExperience);
            if (status)
            {
                return this.RedirectToAction("canhome", "CandidateRegister");

            }
            return View();
        }


        public ActionResult Delete(int id)
        {
            bool status = CandidateWorkExperienceBusinessManager.delete(id);
            if (status == true)
            {
                return this.RedirectToAction("canhome", "CandidateRegister");


            }
            return View();
        }



    }
}